
// cc MaxTemperatureMapper Mapper for maximum temperature example
// vv MaxTemperatureMapper
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


        public class MaxTemperatureMapper
        extends Mapper<LongWritable, Text, Text, Text> {

        public void map(LongWritable key, Text value, Context context)
        throws IOException, InterruptedException {

        String line = value.toString();
        String[] words=line.split(" ");

        if(words.length > 9){
        String datess = words[0].trim();
        datess = datess.substring(0,7);
        String url = words[4].trim();
        String resp = words[10].trim();

        if ((resp.equals("200")) && !(url.contains("index."))){
                if((datess.contains("2016-")) || (datess.contains("2012-")) )

        context.write(new Text(datess), new Text(url));

         }
        }
  }
}
