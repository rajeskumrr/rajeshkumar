// cc MaxTemperatureReducer Reducer for maximum temperature example
// vv MaxTemperatureReducer
import java.io.IOException;
import java.util.Scanner;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.util.List;
import java.util.ArrayList;

public class MaxTemperatureReducer
  extends Reducer<Text, Text, Text, Text> {

  public void reduce(Text key, Iterable<Text> values,
      Context context)
      throws IOException, InterruptedException {

         List<String> vArrayList = new ArrayList<String>();
        for (Text vals : values){
        vArrayList.add(vals.toString());
        }

        int  FinalCount  = 0;
        String FinalUrl = "";

    for(int i=0; i < vArrayList.size() ; i++) {
        int count = 0;
        String OrigUrl = vArrayList.get(i);

        for(int j=0; j < vArrayList.size(); j++) {
        String NewUrl = vArrayList.get(j);
                if (OrigUrl.equals(NewUrl)){
                        count++;
                }
        }
        if (count > FinalCount){
                FinalCount = count;
                FinalUrl = OrigUrl;
        }
  }
        FinalUrl = FinalUrl + "  " +  Long.toString(FinalCount);
        context.write(key, new Text(FinalUrl));
  }
}

